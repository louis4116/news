module.exports = [
  "all",
  "popular",
  "politics",
  "society",
  "life",
  "world",
  "local",
  "novelty",
];
