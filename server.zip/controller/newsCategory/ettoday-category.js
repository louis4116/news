module.exports = ["政治", "社會", "生活", "國際", "大陸"];
