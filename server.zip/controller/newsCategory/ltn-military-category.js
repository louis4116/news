module.exports = [
  "breakingnewslist",
  "mitlist",
  "pedialist",
  "historylist",
  "stylelist",
  "filelist",
  "forumlist",
  "peoplelist",
];
